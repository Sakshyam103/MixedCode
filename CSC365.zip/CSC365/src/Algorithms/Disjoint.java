package Algorithms;

public class Disjoint {

}
